Threat Intelligence Report Package
==================================

This package contains two main components:

1. Threat_Intelligence_Report.docx
   - This is the main, human-readable report containing the executive summary, findings, and remediation advice.

2. Interactive_Appendix.html
   - This is a searchable, interactive file for exploring all raw vulnerability data. Open this file in your web browser.

